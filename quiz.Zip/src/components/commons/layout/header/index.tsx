import styled from "@emotion/styled";

const Wrapper = styled.div`
  width: 1520px;
  height: 50px;
  background-color: red;
`;

export default function HeaderUI() {
  return <Wrapper>This is Header Area</Wrapper>;
}
