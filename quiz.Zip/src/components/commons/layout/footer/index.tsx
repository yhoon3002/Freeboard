import styled from "@emotion/styled";

const Wrapper = styled.div`
  width: 1520px;
  height: 50px;
  background-color: green;
`;

export default function FooterUI() {
  return <Wrapper>This is Footer Area</Wrapper>;
}
