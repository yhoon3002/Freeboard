import styled from "@emotion/styled";

const Wrapper = styled.div`
  width: 350px;
  height: 500px;
  background-color: skyblue;
`;

export default function SidebarUI() {
  return <Wrapper>This is Sidebar Area</Wrapper>;
}
