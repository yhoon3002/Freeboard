export default function One() {
  return <div>three 영역 입니다.</div>;
}
