export default function One() {
  return <div>two 영역 입니다.</div>;
}
