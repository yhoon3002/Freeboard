import RecoilWirtePage from "../../../../src/components/units/recoil/write/RecoilWrite";

export default function RecoilNewPage() {
  return <RecoilWirtePage />;
}
