// This Is For Edit Page

import ProductWriteContainer from "../../../../../src/components/units/quiz-08-01-product-write/ProductWrite.container";

const ProductEditPage = () => {
    return <ProductWriteContainer isEdit={true} />;
};

export default ProductEditPage;
