// This Is For Register Page

import ProductWriteContainer from "../../../../src/components/units/quiz-08-01-product-write/ProductWrite.container";

const ProductNewPage = () => {
    return <ProductWriteContainer isEdit={false} />;
};

export default ProductNewPage;
