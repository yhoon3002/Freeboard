import CreateBoard from "../../../src/components/units/static/routing/CreateBoard.container";

export default function GraphqlMutationPage() {
    return <CreateBoard />;
}
