import FetchBoard from "../../../../src/components/units/static/routed/FetchBoard.container";

export default function staticRoutedPage() {
    return <FetchBoard />;
}
