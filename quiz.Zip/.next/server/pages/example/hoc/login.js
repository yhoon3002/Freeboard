"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/example/hoc/login";
exports.ids = ["pages/example/hoc/login"];
exports.modules = {

/***/ "./pages/example/hoc/login/index.tsx":
/*!*******************************************!*\
  !*** ./pages/example/hoc/login/index.tsx ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ HocLoginPage)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @apollo/client */ \"@apollo/client\");\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! recoil */ \"recoil\");\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_4__);\n/* harmony import */ var _src_commons_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../src/commons/store */ \"./src/commons/store/index.ts\");\n\n\n\n\n\n\nconst LOGIN_USER = _apollo_client__WEBPACK_IMPORTED_MODULE_1__.gql`\n  mutation loginUser($email: String!, $password: String!) {\n    loginUser(email: $email, password: $password) {\n      accessToken\n    }\n  }\n`;\nfunction HocLoginPage() {\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();\n    const [loginUser] = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_1__.useMutation)(LOGIN_USER);\n    const { 0: id , 1: setId  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(\"\");\n    const { 0: password , 1: setPassword  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(\"\");\n    const [, setAccessToken] = (0,recoil__WEBPACK_IMPORTED_MODULE_4__.useRecoilState)(_src_commons_store__WEBPACK_IMPORTED_MODULE_5__.accessTokenState);\n    const onChangeId = (e)=>{\n        setId(e.target.value);\n    };\n    const onChangePassword = (e)=>{\n        setPassword(e.target.value);\n    };\n    const onClickLogin = async ()=>{\n        const result = await loginUser({\n            variables: {\n                email: id,\n                password: password\n            }\n        });\n        const accessToken = result.data.loginUser.accessToken;\n        setAccessToken(accessToken);\n        localStorage.setItem(\"accessToken\", accessToken);\n        alert(\"로그인에 성공하였습니다.\");\n        router.push(\"/example/hoc/main\");\n    };\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: [\n            \"아이디 : \",\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"input\", {\n                type: \"text\",\n                onChange: onChangeId\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\scenr\\\\Desktop\\\\codecamp06-lim\\\\quiz\\\\pages\\\\example\\\\hoc\\\\login\\\\index.tsx\",\n                lineNumber: 46,\n                columnNumber: 13\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"br\", {}, void 0, false, {\n                fileName: \"C:\\\\Users\\\\scenr\\\\Desktop\\\\codecamp06-lim\\\\quiz\\\\pages\\\\example\\\\hoc\\\\login\\\\index.tsx\",\n                lineNumber: 47,\n                columnNumber: 7\n            }, this),\n            \"비밀번호 : \",\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"input\", {\n                type: \"password\",\n                onChange: onChangePassword\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\scenr\\\\Desktop\\\\codecamp06-lim\\\\quiz\\\\pages\\\\example\\\\hoc\\\\login\\\\index.tsx\",\n                lineNumber: 48,\n                columnNumber: 14\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"br\", {}, void 0, false, {\n                fileName: \"C:\\\\Users\\\\scenr\\\\Desktop\\\\codecamp06-lim\\\\quiz\\\\pages\\\\example\\\\hoc\\\\login\\\\index.tsx\",\n                lineNumber: 49,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                onClick: onClickLogin,\n                children: \"로그인하기\"\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\scenr\\\\Desktop\\\\codecamp06-lim\\\\quiz\\\\pages\\\\example\\\\hoc\\\\login\\\\index.tsx\",\n                lineNumber: 50,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9leGFtcGxlL2hvYy9sb2dpbi9pbmRleC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFpRDtBQUNWO0FBQ1A7QUFDTztBQUN5QjtBQUVoRSxLQUFLLENBQUNNLFVBQVUsR0FBR04sK0NBQUcsQ0FBQzs7Ozs7O0FBTXZCO0FBRWUsUUFBUSxDQUFDTyxZQUFZLEdBQUcsQ0FBQztJQUN0QyxLQUFLLENBQUNDLE1BQU0sR0FBR04sc0RBQVM7SUFDeEIsS0FBSyxFQUFFTyxTQUFTLElBQUlSLDJEQUFXLENBQUNLLFVBQVU7SUFDMUMsS0FBSyxNQUFFSSxFQUFFLE1BQUVDLEtBQUssTUFBSVIsK0NBQVEsQ0FBQyxDQUFFO0lBQy9CLEtBQUssTUFBRVMsUUFBUSxNQUFFQyxXQUFXLE1BQUlWLCtDQUFRLENBQUMsQ0FBRTtJQUMzQyxLQUFLLElBQUlXLGNBQWMsSUFBSVYsc0RBQWMsQ0FBQ0MsZ0VBQWdCO0lBRTFELEtBQUssQ0FBQ1UsVUFBVSxJQUFJQyxDQUFDLEdBQUssQ0FBQztRQUN6QkwsS0FBSyxDQUFDSyxDQUFDLENBQUNDLE1BQU0sQ0FBQ0MsS0FBSztJQUN0QixDQUFDO0lBRUQsS0FBSyxDQUFDQyxnQkFBZ0IsSUFBSUgsQ0FBQyxHQUFLLENBQUM7UUFDL0JILFdBQVcsQ0FBQ0csQ0FBQyxDQUFDQyxNQUFNLENBQUNDLEtBQUs7SUFDNUIsQ0FBQztJQUVELEtBQUssQ0FBQ0UsWUFBWSxhQUFlLENBQUM7UUFDaEMsS0FBSyxDQUFDQyxNQUFNLEdBQUcsS0FBSyxDQUFDWixTQUFTLENBQUMsQ0FBQztZQUM5QmEsU0FBUyxFQUFFLENBQUM7Z0JBQ1ZDLEtBQUssRUFBRWIsRUFBRTtnQkFDVEUsUUFBUSxFQUFFQSxRQUFRO1lBQ3BCLENBQUM7UUFDSCxDQUFDO1FBQ0QsS0FBSyxDQUFDWSxXQUFXLEdBQUdILE1BQU0sQ0FBQ0ksSUFBSSxDQUFDaEIsU0FBUyxDQUFDZSxXQUFXO1FBQ3JEVixjQUFjLENBQUNVLFdBQVc7UUFDMUJFLFlBQVksQ0FBQ0MsT0FBTyxDQUFDLENBQWEsY0FBRUgsV0FBVztRQUMvQ0ksS0FBSyxDQUFDLENBQWU7UUFDQ3BCLE1BQWhCLENBQUNxQixJQUFJLENBQUMsQ0FBbUI7SUFDakMsQ0FBQztJQUVELE1BQU07O1lBQ0YsQ0FDTTt3RkFBT0MsQ0FBSztnQkFBQ0MsSUFBSSxFQUFDLENBQU07Z0JBQUNDLFFBQVEsRUFBRWpCLFVBQVU7Ozs7Ozt3RkFDNUNrQixDQUFKOzs7OztZQUFHLENBQ0M7d0ZBQVNILENBQUs7Z0JBQUNDLElBQUksRUFBQyxDQUFVO2dCQUFDQyxRQUFRLEVBQUViLGdCQUFnQjs7Ozs7O3dGQUN2RGMsQ0FBTjs7Ozs7d0ZBQ0ZDLENBQU07Z0JBQUNDLE9BQU8sRUFBRWYsWUFBWTswQkFBRSxDQUFLOzs7Ozs7OztBQUcxQyxDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vcXVpei8uL3BhZ2VzL2V4YW1wbGUvaG9jL2xvZ2luL2luZGV4LnRzeD8yNzhlIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGdxbCwgdXNlTXV0YXRpb24gfSBmcm9tIFwiQGFwb2xsby9jbGllbnRcIjtcclxuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIm5leHQvcm91dGVyXCI7XHJcbmltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IHVzZVJlY29pbFN0YXRlIH0gZnJvbSBcInJlY29pbFwiO1xyXG5pbXBvcnQgeyBhY2Nlc3NUb2tlblN0YXRlIH0gZnJvbSBcIi4uLy4uLy4uLy4uL3NyYy9jb21tb25zL3N0b3JlXCI7XHJcblxyXG5jb25zdCBMT0dJTl9VU0VSID0gZ3FsYFxyXG4gIG11dGF0aW9uIGxvZ2luVXNlcigkZW1haWw6IFN0cmluZyEsICRwYXNzd29yZDogU3RyaW5nISkge1xyXG4gICAgbG9naW5Vc2VyKGVtYWlsOiAkZW1haWwsIHBhc3N3b3JkOiAkcGFzc3dvcmQpIHtcclxuICAgICAgYWNjZXNzVG9rZW5cclxuICAgIH1cclxuICB9XHJcbmA7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBIb2NMb2dpblBhZ2UoKSB7XHJcbiAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XHJcbiAgY29uc3QgW2xvZ2luVXNlcl0gPSB1c2VNdXRhdGlvbihMT0dJTl9VU0VSKTtcclxuICBjb25zdCBbaWQsIHNldElkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtwYXNzd29yZCwgc2V0UGFzc3dvcmRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgWywgc2V0QWNjZXNzVG9rZW5dID0gdXNlUmVjb2lsU3RhdGUoYWNjZXNzVG9rZW5TdGF0ZSk7XHJcblxyXG4gIGNvbnN0IG9uQ2hhbmdlSWQgPSAoZSkgPT4ge1xyXG4gICAgc2V0SWQoZS50YXJnZXQudmFsdWUpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IG9uQ2hhbmdlUGFzc3dvcmQgPSAoZSkgPT4ge1xyXG4gICAgc2V0UGFzc3dvcmQoZS50YXJnZXQudmFsdWUpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IG9uQ2xpY2tMb2dpbiA9IGFzeW5jICgpID0+IHtcclxuICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGxvZ2luVXNlcih7XHJcbiAgICAgIHZhcmlhYmxlczoge1xyXG4gICAgICAgIGVtYWlsOiBpZCxcclxuICAgICAgICBwYXNzd29yZDogcGFzc3dvcmQsXHJcbiAgICAgIH0sXHJcbiAgICB9KTtcclxuICAgIGNvbnN0IGFjY2Vzc1Rva2VuID0gcmVzdWx0LmRhdGEubG9naW5Vc2VyLmFjY2Vzc1Rva2VuO1xyXG4gICAgc2V0QWNjZXNzVG9rZW4oYWNjZXNzVG9rZW4pO1xyXG4gICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJhY2Nlc3NUb2tlblwiLCBhY2Nlc3NUb2tlbik7XHJcbiAgICBhbGVydChcIuuhnOq3uOyduOyXkCDshLHqs7XtlZjsmIDsirXri4jri6QuXCIpO1xyXG4gICAgcm91dGVyLnB1c2goXCIvZXhhbXBsZS9ob2MvbWFpblwiKTtcclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAg7JWE7J2065SUIDogPGlucHV0IHR5cGU9XCJ0ZXh0XCIgb25DaGFuZ2U9e29uQ2hhbmdlSWR9IC8+XHJcbiAgICAgIDxiciAvPlxyXG4gICAgICDruYTrsIDrsojtmLggOiA8aW5wdXQgdHlwZT1cInBhc3N3b3JkXCIgb25DaGFuZ2U9e29uQ2hhbmdlUGFzc3dvcmR9IC8+XHJcbiAgICAgIDxiciAvPlxyXG4gICAgICA8YnV0dG9uIG9uQ2xpY2s9e29uQ2xpY2tMb2dpbn0+66Gc6re47J247ZWY6riwPC9idXR0b24+XHJcbiAgICA8Lz5cclxuICApO1xyXG59XHJcbiJdLCJuYW1lcyI6WyJncWwiLCJ1c2VNdXRhdGlvbiIsInVzZVJvdXRlciIsInVzZVN0YXRlIiwidXNlUmVjb2lsU3RhdGUiLCJhY2Nlc3NUb2tlblN0YXRlIiwiTE9HSU5fVVNFUiIsIkhvY0xvZ2luUGFnZSIsInJvdXRlciIsImxvZ2luVXNlciIsImlkIiwic2V0SWQiLCJwYXNzd29yZCIsInNldFBhc3N3b3JkIiwic2V0QWNjZXNzVG9rZW4iLCJvbkNoYW5nZUlkIiwiZSIsInRhcmdldCIsInZhbHVlIiwib25DaGFuZ2VQYXNzd29yZCIsIm9uQ2xpY2tMb2dpbiIsInJlc3VsdCIsInZhcmlhYmxlcyIsImVtYWlsIiwiYWNjZXNzVG9rZW4iLCJkYXRhIiwibG9jYWxTdG9yYWdlIiwic2V0SXRlbSIsImFsZXJ0IiwicHVzaCIsImlucHV0IiwidHlwZSIsIm9uQ2hhbmdlIiwiYnIiLCJidXR0b24iLCJvbkNsaWNrIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/example/hoc/login/index.tsx\n");

/***/ }),

/***/ "./src/commons/store/index.ts":
/*!************************************!*\
  !*** ./src/commons/store/index.ts ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"accessTokenState\": () => (/* binding */ accessTokenState)\n/* harmony export */ });\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! recoil */ \"recoil\");\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_0__);\n\nconst accessTokenState = (0,recoil__WEBPACK_IMPORTED_MODULE_0__.atom)({\n    key: \"accessTokenState\",\n    default: \"\"\n});\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tbW9ucy9zdG9yZS9pbmRleC50cy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7QUFBNkI7QUFFdEIsS0FBSyxDQUFDQyxnQkFBZ0IsR0FBR0QsNENBQUksQ0FBQyxDQUFDO0lBQ3BDRSxHQUFHLEVBQUUsQ0FBa0I7SUFDdkJDLE9BQU8sRUFBRSxDQUFFO0FBQ2IsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL3F1aXovLi9zcmMvY29tbW9ucy9zdG9yZS9pbmRleC50cz8zY2JmIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGF0b20gfSBmcm9tIFwicmVjb2lsXCI7XHJcblxyXG5leHBvcnQgY29uc3QgYWNjZXNzVG9rZW5TdGF0ZSA9IGF0b20oe1xyXG4gIGtleTogXCJhY2Nlc3NUb2tlblN0YXRlXCIsXHJcbiAgZGVmYXVsdDogXCJcIixcclxufSk7XHJcbiJdLCJuYW1lcyI6WyJhdG9tIiwiYWNjZXNzVG9rZW5TdGF0ZSIsImtleSIsImRlZmF1bHQiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/commons/store/index.ts\n");

/***/ }),

/***/ "@apollo/client":
/*!*********************************!*\
  !*** external "@apollo/client" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "recoil":
/*!*************************!*\
  !*** external "recoil" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("recoil");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/example/hoc/login/index.tsx"));
module.exports = __webpack_exports__;

})();