"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/homework/quiz-11-01";
exports.ids = ["pages/homework/quiz-11-01"];
exports.modules = {

/***/ "./pages/homework/quiz-11-01/index.tsx":
/*!*********************************************!*\
  !*** ./pages/homework/quiz-11-01/index.tsx ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! antd */ \"antd\");\n/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_2__);\n\n// 별점 라이브러리\n\n\nconst QuizFirst = ()=>{\n    const { 0: value1 , 1: setValue  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);\n    const onChangeRate = (value)=>{\n        setValue(value);\n        alert(value + \"점\");\n    };\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_2__.Rate, {\n                onChange: onChangeRate,\n                value: value1\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\scenr\\\\Desktop\\\\codecamp06-lim\\\\quiz\\\\pages\\\\homework\\\\quiz-11-01\\\\index.tsx\",\n                lineNumber: 16,\n                columnNumber: 7\n            }, undefined),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                children: [\n                    value1,\n                    \"점\"\n                ]\n            }, void 0, true, {\n                fileName: \"C:\\\\Users\\\\scenr\\\\Desktop\\\\codecamp06-lim\\\\quiz\\\\pages\\\\homework\\\\quiz-11-01\\\\index.tsx\",\n                lineNumber: 17,\n                columnNumber: 7\n            }, undefined)\n        ]\n    }, void 0, true, {\n        fileName: \"C:\\\\Users\\\\scenr\\\\Desktop\\\\codecamp06-lim\\\\quiz\\\\pages\\\\homework\\\\quiz-11-01\\\\index.tsx\",\n        lineNumber: 15,\n        columnNumber: 5\n    }, undefined));\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (QuizFirst);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9ob21ld29yay9xdWl6LTExLTAxL2luZGV4LnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OztBQUFBLEVBQVc7QUFFcUI7QUFDTDtBQUUzQixLQUFLLENBQUNFLFNBQVMsT0FBUyxDQUFDO0lBQ3ZCLEtBQUssTUFBRUMsTUFBSyxNQUFFQyxRQUFRLE1BQUlKLCtDQUFRLENBQUMsQ0FBQztJQUVwQyxLQUFLLENBQUNLLFlBQVksSUFBSUYsS0FBYSxHQUFLLENBQUM7UUFDdkNDLFFBQVEsQ0FBQ0QsS0FBSztRQUNkRyxLQUFLLENBQUNILEtBQUssR0FBRyxDQUFHO0lBQ2pCLENBQUQ7SUFFRCxNQUFNLDZFQUNISSxDQUFHOzt3RkFDRE4sc0NBQUk7Z0JBQUNPLFFBQVEsRUFBRUgsWUFBWTtnQkFBRUYsS0FBSyxFQUFFQSxNQUFLOzs7Ozs7d0ZBQ3pDSSxDQUFHOztvQkFBRUosTUFBSztvQkFBQyxDQUFDOzs7Ozs7Ozs7Ozs7O0FBR25CLENBQUM7QUFFRCxpRUFBZUQsU0FBUyxFQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vcXVpei8uL3BhZ2VzL2hvbWV3b3JrL3F1aXotMTEtMDEvaW5kZXgudHN4P2JiMWMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8g67OE7KCQIOudvOydtOu4jOufrOumrFxyXG5cclxuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgUmF0ZSB9IGZyb20gXCJhbnRkXCI7XHJcblxyXG5jb25zdCBRdWl6Rmlyc3QgPSAoKSA9PiB7XHJcbiAgY29uc3QgW3ZhbHVlLCBzZXRWYWx1ZV0gPSB1c2VTdGF0ZSgwKTtcclxuXHJcbiAgY29uc3Qgb25DaGFuZ2VSYXRlID0gKHZhbHVlOiBudW1iZXIpID0+IHtcclxuICAgIHNldFZhbHVlKHZhbHVlKTtcclxuICAgIGFsZXJ0KHZhbHVlICsgXCLsoJBcIik7XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXY+XHJcbiAgICAgIDxSYXRlIG9uQ2hhbmdlPXtvbkNoYW5nZVJhdGV9IHZhbHVlPXt2YWx1ZX0gLz5cclxuICAgICAgPGRpdj57dmFsdWV97KCQPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgUXVpekZpcnN0O1xyXG4iXSwibmFtZXMiOlsidXNlU3RhdGUiLCJSYXRlIiwiUXVpekZpcnN0IiwidmFsdWUiLCJzZXRWYWx1ZSIsIm9uQ2hhbmdlUmF0ZSIsImFsZXJ0IiwiZGl2Iiwib25DaGFuZ2UiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/homework/quiz-11-01/index.tsx\n");

/***/ }),

/***/ "antd":
/*!***********************!*\
  !*** external "antd" ***!
  \***********************/
/***/ ((module) => {

module.exports = require("antd");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/homework/quiz-11-01/index.tsx"));
module.exports = __webpack_exports__;

})();