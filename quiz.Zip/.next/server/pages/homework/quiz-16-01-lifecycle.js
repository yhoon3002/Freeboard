"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/homework/quiz-16-01-lifecycle";
exports.ids = ["pages/homework/quiz-16-01-lifecycle"];
exports.modules = {

/***/ "./pages/homework/quiz-16-01-lifecycle/index.tsx":
/*!*******************************************************!*\
  !*** ./pages/homework/quiz-16-01-lifecycle/index.tsx ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ LifeCyclePage)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\nfunction LifeCyclePage() {\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();\n    const { 0: isChange , 1: setIsChange  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);\n    const onClickChange = ()=>{\n        setIsChange((prev)=>!prev\n        );\n    };\n    const onClickMove = ()=>{\n        router.push(\"/\");\n    };\n    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{\n        alert(\"Rendered!\");\n    }, []);\n    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{\n        alert(\"Changed!!\");\n    }, [\n        isChange\n    ]);\n    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{\n        return ()=>{\n            alert(\"Bye!!\");\n        };\n    }, []);\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                onClick: onClickChange,\n                children: \"변경\"\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\scenr\\\\Desktop\\\\codecamp06-lim\\\\quiz\\\\pages\\\\homework\\\\quiz-16-01-lifecycle\\\\index.tsx\",\n                lineNumber: 32,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                onClick: onClickMove,\n                children: \"이동\"\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\scenr\\\\Desktop\\\\codecamp06-lim\\\\quiz\\\\pages\\\\homework\\\\quiz-16-01-lifecycle\\\\index.tsx\",\n                lineNumber: 33,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9ob21ld29yay9xdWl6LTE2LTAxLWxpZmVjeWNsZS9pbmRleC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7QUFBMkM7QUFDSTtBQUVoQyxRQUFRLENBQUNHLGFBQWEsR0FBRyxDQUFDO0lBQ3ZDLEtBQUssQ0FBQ0MsTUFBTSxHQUFHRixzREFBUztJQUN4QixLQUFLLE1BQUVHLFFBQVEsTUFBRUMsV0FBVyxNQUFJTCwrQ0FBUSxDQUFDLEtBQUs7SUFFOUMsS0FBSyxDQUFDTSxhQUFhLE9BQVMsQ0FBQztRQUMzQkQsV0FBVyxFQUFFRSxJQUFJLElBQU1BLElBQUk7O0lBQzdCLENBQUM7SUFFRCxLQUFLLENBQUNDLFdBQVcsT0FBUyxDQUFDO1FBQ3pCTCxNQUFNLENBQUNNLElBQUksQ0FBQyxDQUFHO0lBQ2pCLENBQUM7SUFFRFYsZ0RBQVMsS0FBTyxDQUFDO1FBQ2ZXLEtBQUssQ0FBQyxDQUFXO0lBQ25CLENBQUMsRUFBRSxDQUFDLENBQUM7SUFFTFgsZ0RBQVMsS0FBTyxDQUFDO1FBQ2ZXLEtBQUssQ0FBQyxDQUFXO0lBQ25CLENBQUMsRUFBRSxDQUFDTjtRQUFBQSxRQUFRO0lBQUEsQ0FBQztJQUViTCxnREFBUyxLQUFPLENBQUM7UUFDZixNQUFNLEtBQU8sQ0FBQztZQUNaVyxLQUFLLENBQUMsQ0FBTztRQUNmLENBQUM7SUFDSCxDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBRUwsTUFBTTs7d0ZBRURDLENBQU07Z0JBQUNDLE9BQU8sRUFBRU4sYUFBYTswQkFBRSxDQUFFOzs7Ozs7d0ZBQzdCSyxDQUFFO2dCQUFDQyxPQUFPLEVBQUVKLFdBQVc7MEJBQUUsQ0FBRTs7Ozs7Ozs7QUFHdEMsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL3F1aXovLi9wYWdlcy9ob21ld29yay9xdWl6LTE2LTAxLWxpZmVjeWNsZS9pbmRleC50c3g/NDdhZCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IHJvdXRlciwgdXNlUm91dGVyIH0gZnJvbSBcIm5leHQvcm91dGVyXCI7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBMaWZlQ3ljbGVQYWdlKCkge1xyXG4gIGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xyXG4gIGNvbnN0IFtpc0NoYW5nZSwgc2V0SXNDaGFuZ2VdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICBjb25zdCBvbkNsaWNrQ2hhbmdlID0gKCkgPT4ge1xyXG4gICAgc2V0SXNDaGFuZ2UoKHByZXYpID0+ICFwcmV2KTtcclxuICB9O1xyXG5cclxuICBjb25zdCBvbkNsaWNrTW92ZSA9ICgpID0+IHtcclxuICAgIHJvdXRlci5wdXNoKFwiL1wiKTtcclxuICB9O1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgYWxlcnQoXCJSZW5kZXJlZCFcIik7XHJcbiAgfSwgW10pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgYWxlcnQoXCJDaGFuZ2VkISFcIik7XHJcbiAgfSwgW2lzQ2hhbmdlXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICByZXR1cm4gKCkgPT4ge1xyXG4gICAgICBhbGVydChcIkJ5ZSEhXCIpO1xyXG4gICAgfTtcclxuICB9LCBbXSk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICA8YnV0dG9uIG9uQ2xpY2s9e29uQ2xpY2tDaGFuZ2V9PuuzgOqyvTwvYnV0dG9uPlxyXG4gICAgICA8YnV0dG9uIG9uQ2xpY2s9e29uQ2xpY2tNb3ZlfT7snbTrj5k8L2J1dHRvbj5cclxuICAgIDwvPlxyXG4gICk7XHJcbn1cclxuIl0sIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVN0YXRlIiwidXNlUm91dGVyIiwiTGlmZUN5Y2xlUGFnZSIsInJvdXRlciIsImlzQ2hhbmdlIiwic2V0SXNDaGFuZ2UiLCJvbkNsaWNrQ2hhbmdlIiwicHJldiIsIm9uQ2xpY2tNb3ZlIiwicHVzaCIsImFsZXJ0IiwiYnV0dG9uIiwib25DbGljayJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/homework/quiz-16-01-lifecycle/index.tsx\n");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/homework/quiz-16-01-lifecycle/index.tsx"));
module.exports = __webpack_exports__;

})();