"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/homework/quiz-06-02-dynamic-routed/[number]";
exports.ids = ["pages/homework/quiz-06-02-dynamic-routed/[number]"];
exports.modules = {

/***/ "./pages/homework/quiz-06-02-dynamic-routed/[number]/index.js":
/*!********************************************************************!*\
  !*** ./pages/homework/quiz-06-02-dynamic-routed/[number]/index.js ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ staticRoutedPage)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _src_components_units_static_routed_FetchBoard_container__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../src/components/units/static/routed/FetchBoard.container */ \"./src/components/units/static/routed/FetchBoard.container.js\");\n\n\nfunction staticRoutedPage() {\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_src_components_units_static_routed_FetchBoard_container__WEBPACK_IMPORTED_MODULE_1__[\"default\"], {}, void 0, false, {\n        fileName: \"C:\\\\Users\\\\scenr\\\\Desktop\\\\codecamp06-lim\\\\quiz\\\\pages\\\\homework\\\\quiz-06-02-dynamic-routed\\\\[number]\\\\index.js\",\n        lineNumber: 4,\n        columnNumber: 12\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9ob21ld29yay9xdWl6LTA2LTAyLWR5bmFtaWMtcm91dGVkL1tudW1iZXJdL2luZGV4LmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQTRGO0FBRTdFLFFBQVEsQ0FBQ0MsZ0JBQWdCLEdBQUcsQ0FBQztJQUN4QyxNQUFNLDZFQUFFRCxnR0FBVTs7Ozs7QUFDdEIsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL3F1aXovLi9wYWdlcy9ob21ld29yay9xdWl6LTA2LTAyLWR5bmFtaWMtcm91dGVkL1tudW1iZXJdL2luZGV4LmpzPzM1OGIiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IEZldGNoQm9hcmQgZnJvbSBcIi4uLy4uLy4uLy4uL3NyYy9jb21wb25lbnRzL3VuaXRzL3N0YXRpYy9yb3V0ZWQvRmV0Y2hCb2FyZC5jb250YWluZXJcIjtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIHN0YXRpY1JvdXRlZFBhZ2UoKSB7XHJcbiAgICByZXR1cm4gPEZldGNoQm9hcmQgLz47XHJcbn1cclxuIl0sIm5hbWVzIjpbIkZldGNoQm9hcmQiLCJzdGF0aWNSb3V0ZWRQYWdlIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/homework/quiz-06-02-dynamic-routed/[number]/index.js\n");

/***/ }),

/***/ "./src/components/units/static/routed/FetchBoard.container.js":
/*!********************************************************************!*\
  !*** ./src/components/units/static/routed/FetchBoard.container.js ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ FetchBoard)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _FetchBoard_presenter__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./FetchBoard.presenter */ \"./src/components/units/static/routed/FetchBoard.presenter.js\");\n/* harmony import */ var _FetchBoard_queries__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./FetchBoard.queries */ \"./src/components/units/static/routed/FetchBoard.queries.js\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @apollo/client */ \"@apollo/client\");\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_4__);\n\n\n\n\n\nfunction FetchBoard() {\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();\n    console.log(router);\n    // 요로코롱 하면 data를 요청하고 받을 때까지 기다려주지 않기 때문에\n    // data에는 undefined가 들어와짐!\n    const { data  } = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_4__.useQuery)(_FetchBoard_queries__WEBPACK_IMPORTED_MODULE_2__.FETCH_BOARD, {\n        variables: {\n            number: Number(router.query.number)\n        }\n    });\n    console.log(data);\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_FetchBoard_presenter__WEBPACK_IMPORTED_MODULE_1__[\"default\"], {\n        data: data\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\scenr\\\\Desktop\\\\codecamp06-lim\\\\quiz\\\\src\\\\components\\\\units\\\\static\\\\routed\\\\FetchBoard.container.js\",\n        lineNumber: 18,\n        columnNumber: 12\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy91bml0cy9zdGF0aWMvcm91dGVkL0ZldGNoQm9hcmQuY29udGFpbmVyLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7QUFBaUQ7QUFDQztBQUNYO0FBQ0U7QUFFMUIsUUFBUSxDQUFDSSxVQUFVLEdBQUcsQ0FBQztJQUNsQyxLQUFLLENBQUNDLE1BQU0sR0FBR0gsc0RBQVM7SUFDeEJJLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDRixNQUFNO0lBRWxCLEVBQXlDO0lBQ1csRUFBMUI7SUFDMUIsS0FBSyxDQUFDLENBQUMsQ0FBQ0csSUFBSSxFQUFDLENBQUMsR0FBR0wsd0RBQVEsQ0FBQ0YsNERBQVcsRUFBRSxDQUFDO1FBQ3BDUSxTQUFTLEVBQUUsQ0FBQztZQUFDQyxNQUFNLEVBQUVDLE1BQU0sQ0FBQ04sTUFBTSxDQUFDTyxLQUFLLENBQUNGLE1BQU07UUFBRSxDQUFDO0lBQ3RELENBQUM7SUFFREosT0FBTyxDQUFDQyxHQUFHLENBQUNDLElBQUk7SUFFaEIsTUFBTSw2RUFBRVIsNkRBQVk7UUFBQ1EsSUFBSSxFQUFFQSxJQUFJOzs7Ozs7QUFDbkMsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL3F1aXovLi9zcmMvY29tcG9uZW50cy91bml0cy9zdGF0aWMvcm91dGVkL0ZldGNoQm9hcmQuY29udGFpbmVyLmpzPzQ5ODEiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IEZldGNoQm9hcmRVSSBmcm9tIFwiLi9GZXRjaEJvYXJkLnByZXNlbnRlclwiO1xyXG5pbXBvcnQgeyBGRVRDSF9CT0FSRCB9IGZyb20gXCIuL0ZldGNoQm9hcmQucXVlcmllc1wiO1xyXG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tIFwibmV4dC9yb3V0ZXJcIjtcclxuaW1wb3J0IHsgdXNlUXVlcnkgfSBmcm9tIFwiQGFwb2xsby9jbGllbnRcIjtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEZldGNoQm9hcmQoKSB7XHJcbiAgICBjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcclxuICAgIGNvbnNvbGUubG9nKHJvdXRlcik7XHJcblxyXG4gICAgLy8g7JqU66Gc7L2U66GxIO2VmOuptCBkYXRh66W8IOyalOyyre2VmOqzoCDrsJvsnYQg65WM6rmM7KeAIOq4sOuLpOugpOyjvOyngCDslYrquLAg65WM66y47JeQXHJcbiAgICAvLyBkYXRh7JeQ64qUIHVuZGVmaW5lZOqwgCDrk6TslrTsmYDsp5AhXHJcbiAgICBjb25zdCB7IGRhdGEgfSA9IHVzZVF1ZXJ5KEZFVENIX0JPQVJELCB7XHJcbiAgICAgICAgdmFyaWFibGVzOiB7IG51bWJlcjogTnVtYmVyKHJvdXRlci5xdWVyeS5udW1iZXIpIH0sXHJcbiAgICB9KTtcclxuXHJcbiAgICBjb25zb2xlLmxvZyhkYXRhKTtcclxuXHJcbiAgICByZXR1cm4gPEZldGNoQm9hcmRVSSBkYXRhPXtkYXRhfSAvPjtcclxufVxyXG4iXSwibmFtZXMiOlsiRmV0Y2hCb2FyZFVJIiwiRkVUQ0hfQk9BUkQiLCJ1c2VSb3V0ZXIiLCJ1c2VRdWVyeSIsIkZldGNoQm9hcmQiLCJyb3V0ZXIiLCJjb25zb2xlIiwibG9nIiwiZGF0YSIsInZhcmlhYmxlcyIsIm51bWJlciIsIk51bWJlciIsInF1ZXJ5Il0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./src/components/units/static/routed/FetchBoard.container.js\n");

/***/ }),

/***/ "./src/components/units/static/routed/FetchBoard.presenter.js":
/*!********************************************************************!*\
  !*** ./src/components/units/static/routed/FetchBoard.presenter.js ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ FetchBoardUI)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _FetchBoard_styles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./FetchBoard.styles */ \"./src/components/units/static/routed/FetchBoard.styles.js\");\n\n\nfunction FetchBoardUI(props) {\n    var ref, ref1, ref2, ref3, ref4, ref5, ref6, ref7;\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_FetchBoard_styles__WEBPACK_IMPORTED_MODULE_1__.Welcome, {\n                children: [\n                    (ref = props.data) === null || ref === void 0 ? void 0 : (ref1 = ref.fetchBoard) === null || ref1 === void 0 ? void 0 : ref1.number,\n                    \"번 게시글에 오신 것을 환영합니다!!!\"\n                ]\n            }, void 0, true, {\n                fileName: \"C:\\\\Users\\\\scenr\\\\Desktop\\\\codecamp06-lim\\\\quiz\\\\src\\\\components\\\\units\\\\static\\\\routed\\\\FetchBoard.presenter.js\",\n                lineNumber: 6,\n                columnNumber: 13\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_FetchBoard_styles__WEBPACK_IMPORTED_MODULE_1__.Title, {\n                children: [\n                    \"제목 : \",\n                    (ref2 = props.data) === null || ref2 === void 0 ? void 0 : (ref3 = ref2.fetchBoard) === null || ref3 === void 0 ? void 0 : ref3.title\n                ]\n            }, void 0, true, {\n                fileName: \"C:\\\\Users\\\\scenr\\\\Desktop\\\\codecamp06-lim\\\\quiz\\\\src\\\\components\\\\units\\\\static\\\\routed\\\\FetchBoard.presenter.js\",\n                lineNumber: 12,\n                columnNumber: 13\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_FetchBoard_styles__WEBPACK_IMPORTED_MODULE_1__.Writer, {\n                children: [\n                    \"작성자 : \",\n                    (ref4 = props.data) === null || ref4 === void 0 ? void 0 : (ref5 = ref4.fetchBoard) === null || ref5 === void 0 ? void 0 : ref5.writer\n                ]\n            }, void 0, true, {\n                fileName: \"C:\\\\Users\\\\scenr\\\\Desktop\\\\codecamp06-lim\\\\quiz\\\\src\\\\components\\\\units\\\\static\\\\routed\\\\FetchBoard.presenter.js\",\n                lineNumber: 13,\n                columnNumber: 13\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_FetchBoard_styles__WEBPACK_IMPORTED_MODULE_1__.Contents, {\n                children: [\n                    \"내용 : \",\n                    (ref6 = props.data) === null || ref6 === void 0 ? void 0 : (ref7 = ref6.fetchBoard) === null || ref7 === void 0 ? void 0 : ref7.contents\n                ]\n            }, void 0, true, {\n                fileName: \"C:\\\\Users\\\\scenr\\\\Desktop\\\\codecamp06-lim\\\\quiz\\\\src\\\\components\\\\units\\\\static\\\\routed\\\\FetchBoard.presenter.js\",\n                lineNumber: 14,\n                columnNumber: 13\n            }, this)\n        ]\n    }, void 0, true));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy91bml0cy9zdGF0aWMvcm91dGVkL0ZldGNoQm9hcmQucHJlc2VudGVyLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQXNFO0FBRXZELFFBQVEsQ0FBQ0ksWUFBWSxDQUFDQyxLQUFLLEVBQUUsQ0FBQztRQUk1QkEsR0FBVSxRQUtGQSxJQUFjLFFBQ1JBLElBQVksUUFDVEEsSUFBSTtJQVZsQyxNQUFNOzt3RkFFR0wsdURBQU87O3FCQUNISyxHQUFVLEdBQVZBLEtBQUssQ0FBQ0MsSUFBSSxjQUFWRCxHQUFVLEtBQVZBLElBQUksQ0FBSkEsQ0FBc0IsR0FBdEJBLElBQUksQ0FBSkEsQ0FBc0IsV0FBdEJBLEdBQVUsQ0FBRUUsVUFBVSx1QkFBdEJGLElBQUksQ0FBSkEsQ0FBc0IsR0FBdEJBLElBQUksQ0FBSkEsQ0FBc0IsUUFBRUcsTUFBTTtvQkFBQyxDQUVoQzs7Ozs7Ozt3RkFHSFAscURBQUs7O29CQUFDLENBQVM7cUJBQUNJLElBQVUsR0FBVkEsS0FBSyxDQUFDQyxJQUFJLGNBQVZELElBQVUsS0FBVkEsSUFBSSxDQUFKQSxDQUFzQixHQUF0QkEsSUFBSSxDQUFKQSxDQUFzQixXQUF0QkEsSUFBVSxDQUFFRSxVQUFVLHVCQUF0QkYsSUFBSSxDQUFKQSxDQUFzQixHQUF0QkEsSUFBSSxDQUFKQSxDQUFzQixRQUFFSSxLQUFLOzs7Ozs7O3dGQUM3Q1Asc0RBQU07O29CQUFDLENBQVk7cUJBQUNHLElBQVUsR0FBVkEsS0FBSyxDQUFDQyxJQUFJLGNBQVZELElBQVUsS0FBVkEsSUFBSSxDQUFKQSxDQUFzQixHQUF0QkEsSUFBSSxDQUFKQSxDQUFzQixXQUF0QkEsSUFBVSxDQUFFRSxVQUFVLHVCQUF0QkYsSUFBSSxDQUFKQSxDQUFzQixHQUF0QkEsSUFBSSxDQUFKQSxDQUFzQixRQUFFSyxNQUFNOzs7Ozs7O3dGQUNsRFAsd0RBQVE7O29CQUFDLENBQUs7cUJBQUNFLElBQVUsR0FBVkEsS0FBSyxDQUFDQyxJQUFJLGNBQVZELElBQVUsS0FBVkEsSUFBSSxDQUFKQSxDQUFzQixHQUF0QkEsSUFBSSxDQUFKQSxDQUFzQixXQUF0QkEsSUFBVSxDQUFFRSxVQUFVLHVCQUF0QkYsSUFBSSxDQUFKQSxDQUFzQixHQUF0QkEsSUFBSSxDQUFKQSxDQUFzQixRQUFFTSxRQUFROzs7Ozs7Ozs7QUFHNUQsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL3F1aXovLi9zcmMvY29tcG9uZW50cy91bml0cy9zdGF0aWMvcm91dGVkL0ZldGNoQm9hcmQucHJlc2VudGVyLmpzP2U4NmEiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgV2VsY29tZSwgVGl0bGUsIFdyaXRlciwgQ29udGVudHMgfSBmcm9tIFwiLi9GZXRjaEJvYXJkLnN0eWxlc1wiO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gRmV0Y2hCb2FyZFVJKHByb3BzKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDw+XHJcbiAgICAgICAgICAgIDxXZWxjb21lPlxyXG4gICAgICAgICAgICAgICAge3Byb3BzLmRhdGE/LmZldGNoQm9hcmQ/Lm51bWJlcn3rsogg6rKM7Iuc6riA7JeQIOyYpOyLoCDqsoPsnYRcclxuICAgICAgICAgICAgICAgIO2ZmOyYge2VqeuLiOuLpCEhIVxyXG4gICAgICAgICAgICAgICAgey8qIGRhdGEgJiYgOiDsobDqsbTrtoAg66CM642U66eBICovfVxyXG4gICAgICAgICAgICAgICAgey8qIGRhdGE/IDog65Kk7JeQ67aZ7J2AID/rpbwgb3B0aW9uYWwtY2hhaW5pbmfsnbTrnbwg7ZWoKi99XHJcbiAgICAgICAgICAgIDwvV2VsY29tZT5cclxuICAgICAgICAgICAgPFRpdGxlPuygnOuqqSA6IHtwcm9wcy5kYXRhPy5mZXRjaEJvYXJkPy50aXRsZX08L1RpdGxlPlxyXG4gICAgICAgICAgICA8V3JpdGVyPuyekeyEseyekCA6IHtwcm9wcy5kYXRhPy5mZXRjaEJvYXJkPy53cml0ZXJ9PC9Xcml0ZXI+XHJcbiAgICAgICAgICAgIDxDb250ZW50cz7rgrTsmqkgOiB7cHJvcHMuZGF0YT8uZmV0Y2hCb2FyZD8uY29udGVudHN9PC9Db250ZW50cz5cclxuICAgICAgICA8Lz5cclxuICAgICk7XHJcbn1cclxuIl0sIm5hbWVzIjpbIldlbGNvbWUiLCJUaXRsZSIsIldyaXRlciIsIkNvbnRlbnRzIiwiRmV0Y2hCb2FyZFVJIiwicHJvcHMiLCJkYXRhIiwiZmV0Y2hCb2FyZCIsIm51bWJlciIsInRpdGxlIiwid3JpdGVyIiwiY29udGVudHMiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/components/units/static/routed/FetchBoard.presenter.js\n");

/***/ }),

/***/ "./src/components/units/static/routed/FetchBoard.queries.js":
/*!******************************************************************!*\
  !*** ./src/components/units/static/routed/FetchBoard.queries.js ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"FETCH_BOARD\": () => (/* binding */ FETCH_BOARD)\n/* harmony export */ });\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @apollo/client */ \"@apollo/client\");\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_0__);\n\nconst FETCH_BOARD = _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`\n    query fetchBoard($number: Int) {\n        fetchBoard(number: $number) {\n            number\n            writer\n            title\n            contents\n        }\n    }\n`;\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy91bml0cy9zdGF0aWMvcm91dGVkL0ZldGNoQm9hcmQucXVlcmllcy5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7QUFBb0M7QUFFN0IsS0FBSyxDQUFDQyxXQUFXLEdBQUdELCtDQUFHLENBQUM7Ozs7Ozs7OztBQVMvQiIsInNvdXJjZXMiOlsid2VicGFjazovL3F1aXovLi9zcmMvY29tcG9uZW50cy91bml0cy9zdGF0aWMvcm91dGVkL0ZldGNoQm9hcmQucXVlcmllcy5qcz9hMzljIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGdxbCB9IGZyb20gXCJAYXBvbGxvL2NsaWVudFwiO1xyXG5cclxuZXhwb3J0IGNvbnN0IEZFVENIX0JPQVJEID0gZ3FsYFxyXG4gICAgcXVlcnkgZmV0Y2hCb2FyZCgkbnVtYmVyOiBJbnQpIHtcclxuICAgICAgICBmZXRjaEJvYXJkKG51bWJlcjogJG51bWJlcikge1xyXG4gICAgICAgICAgICBudW1iZXJcclxuICAgICAgICAgICAgd3JpdGVyXHJcbiAgICAgICAgICAgIHRpdGxlXHJcbiAgICAgICAgICAgIGNvbnRlbnRzXHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5gO1xyXG4iXSwibmFtZXMiOlsiZ3FsIiwiRkVUQ0hfQk9BUkQiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/components/units/static/routed/FetchBoard.queries.js\n");

/***/ }),

/***/ "./src/components/units/static/routed/FetchBoard.styles.js":
/*!*****************************************************************!*\
  !*** ./src/components/units/static/routed/FetchBoard.styles.js ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"Welcome\": () => (/* binding */ Welcome),\n/* harmony export */   \"Title\": () => (/* binding */ Title),\n/* harmony export */   \"Writer\": () => (/* binding */ Writer),\n/* harmony export */   \"Contents\": () => (/* binding */ Contents)\n/* harmony export */ });\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled */ \"@emotion/styled\");\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_0__);\n\nconst Welcome = (_emotion_styled__WEBPACK_IMPORTED_MODULE_0___default().div)`\n    font-size: 30px;\n    color: yellowgreen;\n    padding-bottom: 40px;\n    text-align: center;\n`;\nconst Title = (_emotion_styled__WEBPACK_IMPORTED_MODULE_0___default().div)`\n    font-size: 20px;\n    font-weight: bold;\n    color: peru;\n    text-align: center;\n`;\nconst Writer = (_emotion_styled__WEBPACK_IMPORTED_MODULE_0___default().div)`\n    font-size: 16px;\n    color: royalblue;\n    text-align: right;\n    padding-right: 100px;\n`;\nconst Contents = (_emotion_styled__WEBPACK_IMPORTED_MODULE_0___default().div)`\n    width: 300px;\n    height: 300px;\n    border: 1px thin purple;\n`;\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy91bml0cy9zdGF0aWMvcm91dGVkL0ZldGNoQm9hcmQuc3R5bGVzLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFvQztBQUU3QixLQUFLLENBQUNDLE9BQU8sR0FBR0QsNERBQVUsQ0FBQzs7Ozs7QUFLbEM7QUFFTyxLQUFLLENBQUNHLEtBQUssR0FBR0gsNERBQVUsQ0FBQzs7Ozs7QUFLaEM7QUFFTyxLQUFLLENBQUNJLE1BQU0sR0FBR0osNERBQVUsQ0FBQzs7Ozs7QUFLakM7QUFFTyxLQUFLLENBQUNLLFFBQVEsR0FBR0wsNERBQVUsQ0FBQzs7OztBQUluQyIsInNvdXJjZXMiOlsid2VicGFjazovL3F1aXovLi9zcmMvY29tcG9uZW50cy91bml0cy9zdGF0aWMvcm91dGVkL0ZldGNoQm9hcmQuc3R5bGVzLmpzP2Y4MzkiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHN0eWxlZCBmcm9tIFwiQGVtb3Rpb24vc3R5bGVkXCI7XHJcblxyXG5leHBvcnQgY29uc3QgV2VsY29tZSA9IHN0eWxlZC5kaXZgXHJcbiAgICBmb250LXNpemU6IDMwcHg7XHJcbiAgICBjb2xvcjogeWVsbG93Z3JlZW47XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogNDBweDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBUaXRsZSA9IHN0eWxlZC5kaXZgXHJcbiAgICBmb250LXNpemU6IDIwcHg7XHJcbiAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgIGNvbG9yOiBwZXJ1O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG5gO1xyXG5cclxuZXhwb3J0IGNvbnN0IFdyaXRlciA9IHN0eWxlZC5kaXZgXHJcbiAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICBjb2xvcjogcm95YWxibHVlO1xyXG4gICAgdGV4dC1hbGlnbjogcmlnaHQ7XHJcbiAgICBwYWRkaW5nLXJpZ2h0OiAxMDBweDtcclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBDb250ZW50cyA9IHN0eWxlZC5kaXZgXHJcbiAgICB3aWR0aDogMzAwcHg7XHJcbiAgICBoZWlnaHQ6IDMwMHB4O1xyXG4gICAgYm9yZGVyOiAxcHggdGhpbiBwdXJwbGU7XHJcbmA7XHJcbiJdLCJuYW1lcyI6WyJzdHlsZWQiLCJXZWxjb21lIiwiZGl2IiwiVGl0bGUiLCJXcml0ZXIiLCJDb250ZW50cyJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/components/units/static/routed/FetchBoard.styles.js\n");

/***/ }),

/***/ "@apollo/client":
/*!*********************************!*\
  !*** external "@apollo/client" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ "@emotion/styled":
/*!**********************************!*\
  !*** external "@emotion/styled" ***!
  \**********************************/
/***/ ((module) => {

module.exports = require("@emotion/styled");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/homework/quiz-06-02-dynamic-routed/[number]/index.js"));
module.exports = __webpack_exports__;

})();