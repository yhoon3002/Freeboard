"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/homework/quiz-23-01-hof";
exports.ids = ["pages/homework/quiz-23-01-hof"];
exports.modules = {

/***/ "./pages/homework/quiz-23-01-hof/index.tsx":
/*!*************************************************!*\
  !*** ./pages/homework/quiz-23-01-hof/index.tsx ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ HofPage)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n\nfunction HofPage() {\n    const onClickButton = (aaa)=>(e)=>{\n            console.log(aaa);\n        }\n    ;\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n            onClick: onClickButton(123),\n            children: \"this is button button button button\"\n        }, void 0, false, {\n            fileName: \"C:\\\\Users\\\\scenr\\\\Desktop\\\\codecamp06-lim\\\\quiz\\\\pages\\\\homework\\\\quiz-23-01-hof\\\\index.tsx\",\n            lineNumber: 8,\n            columnNumber: 7\n        }, this)\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\scenr\\\\Desktop\\\\codecamp06-lim\\\\quiz\\\\pages\\\\homework\\\\quiz-23-01-hof\\\\index.tsx\",\n        lineNumber: 7,\n        columnNumber: 5\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9ob21ld29yay9xdWl6LTIzLTAxLWhvZi9pbmRleC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUFlLFFBQVEsQ0FBQ0EsT0FBTyxHQUFHLENBQUM7SUFDakMsS0FBSyxDQUFDQyxhQUFhLElBQUlDLEdBQUcsSUFBTUMsQ0FBQyxHQUFLLENBQUM7WUFDckNDLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDSCxHQUFHO1FBQ2pCLENBQUM7O0lBRUQsTUFBTSw2RUFDSEksQ0FBRzs4RkFDREMsQ0FBTTtZQUFDQyxPQUFPLEVBQUVQLGFBQWEsQ0FBQyxHQUFHO3NCQUFHLENBRXJDOzs7Ozs7Ozs7OztBQUdOLENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9xdWl6Ly4vcGFnZXMvaG9tZXdvcmsvcXVpei0yMy0wMS1ob2YvaW5kZXgudHN4P2U5ZGIiXSwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gSG9mUGFnZSgpIHtcclxuICBjb25zdCBvbkNsaWNrQnV0dG9uID0gKGFhYSkgPT4gKGUpID0+IHtcclxuICAgIGNvbnNvbGUubG9nKGFhYSk7XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXY+XHJcbiAgICAgIDxidXR0b24gb25DbGljaz17b25DbGlja0J1dHRvbigxMjMpfT5cclxuICAgICAgICB0aGlzIGlzIGJ1dHRvbiBidXR0b24gYnV0dG9uIGJ1dHRvblxyXG4gICAgICA8L2J1dHRvbj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuIl0sIm5hbWVzIjpbIkhvZlBhZ2UiLCJvbkNsaWNrQnV0dG9uIiwiYWFhIiwiZSIsImNvbnNvbGUiLCJsb2ciLCJkaXYiLCJidXR0b24iLCJvbkNsaWNrIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/homework/quiz-23-01-hof/index.tsx\n");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/homework/quiz-23-01-hof/index.tsx"));
module.exports = __webpack_exports__;

})();