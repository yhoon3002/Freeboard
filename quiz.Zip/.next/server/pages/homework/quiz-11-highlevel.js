"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/homework/quiz-11-highlevel";
exports.ids = ["pages/homework/quiz-11-highlevel"];
exports.modules = {

/***/ "./pages/homework/quiz-11-highlevel/index.tsx":
/*!****************************************************!*\
  !*** ./pages/homework/quiz-11-highlevel/index.tsx ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @emotion/styled */ \"@emotion/styled\");\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\nconst QuizLevelUp = ()=>{\n    const Wrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`\n    display: flex;\n    flex-direction: row;\n  `;\n    const GrayStar = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`\n    width: 20px;\n    height: 20px;\n    background-image: url(\"/image/grayStar/grayStar.png\");\n    background-repeat: no-repeat;\n    cursor: pointer;\n  `;\n    const YellowStar = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`\n    width: 20px;\n    height: 20px;\n    background-image: url() (\"/image/yellowStar/yellowStar.png\");\n    cursor: pointer;\n  `;\n    const { 0: isSelected , 1: setIsSelected  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);\n    const onClickStar = (e)=>{\n        setIsSelected(isSelected);\n        e.target.value = isSelected;\n    };\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Wrapper, {\n        children: [\n            1,\n            2,\n            3,\n            4,\n            5\n        ].map((el)=>{\n            return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(GrayStar, {\n                onClick: onClickStar\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\scenr\\\\Desktop\\\\codecamp06-lim\\\\quiz\\\\pages\\\\homework\\\\quiz-11-highlevel\\\\index.tsx\",\n                lineNumber: 35,\n                columnNumber: 16\n            }, undefined));\n        })\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\scenr\\\\Desktop\\\\codecamp06-lim\\\\quiz\\\\pages\\\\homework\\\\quiz-11-highlevel\\\\index.tsx\",\n        lineNumber: 33,\n        columnNumber: 5\n    }, undefined));\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (QuizLevelUp);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9ob21ld29yay9xdWl6LTExLWhpZ2hsZXZlbC9pbmRleC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7QUFBb0M7QUFDSjtBQUVoQyxLQUFLLENBQUNFLFdBQVcsT0FBUyxDQUFDO0lBQ3pCLEtBQUssQ0FBQ0MsT0FBTyxHQUFHSCw0REFBVSxDQUFDOzs7RUFHM0I7SUFFQSxLQUFLLENBQUNLLFFBQVEsR0FBR0wsNERBQVUsQ0FBQzs7Ozs7O0VBTTVCO0lBRUEsS0FBSyxDQUFDTSxVQUFVLEdBQUdOLDREQUFVLENBQUM7Ozs7O0VBSzlCO0lBRUEsS0FBSyxNQUFFTyxVQUFVLE1BQUVDLGFBQWEsTUFBSVAsK0NBQVEsQ0FBQyxLQUFLO0lBRWxELEtBQUssQ0FBQ1EsV0FBVyxJQUFJQyxDQUFDLEdBQUssQ0FBQztRQUMxQkYsYUFBYSxDQUFDRCxVQUFVO1FBQ3hCRyxDQUFDLENBQUNDLE1BQU0sQ0FBQ0MsS0FBSyxHQUFHTCxVQUFVO0lBQzdCLENBQUM7SUFFRCxNQUFNLDZFQUNISixPQUFPO2tCQUNMLENBQUM7QUFBQSxhQUFDO0FBQUUsYUFBQztBQUFFLGFBQUM7QUFBRSxhQUFDO0FBQUUsYUFBQztRQUFBLENBQUMsQ0FBQ1UsR0FBRyxFQUFFQyxFQUFFLEdBQUssQ0FBQztZQUM1QixNQUFNLDZFQUFFVCxRQUFRO2dCQUFDVSxPQUFPLEVBQUVOLFdBQVc7Ozs7OztRQUN2QyxDQUFDOzs7Ozs7QUFHUCxDQUFDO0FBRUQsaUVBQWVQLFdBQVcsRUFBQyIsInNvdXJjZXMiOlsid2VicGFjazovL3F1aXovLi9wYWdlcy9ob21ld29yay9xdWl6LTExLWhpZ2hsZXZlbC9pbmRleC50c3g/NzBhOSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgc3R5bGVkIGZyb20gXCJAZW1vdGlvbi9zdHlsZWRcIjtcclxuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuXHJcbmNvbnN0IFF1aXpMZXZlbFVwID0gKCkgPT4ge1xyXG4gIGNvbnN0IFdyYXBwZXIgPSBzdHlsZWQuZGl2YFxyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGZsZXgtZGlyZWN0aW9uOiByb3c7XHJcbiAgYDtcclxuXHJcbiAgY29uc3QgR3JheVN0YXIgPSBzdHlsZWQuZGl2YFxyXG4gICAgd2lkdGg6IDIwcHg7XHJcbiAgICBoZWlnaHQ6IDIwcHg7XHJcbiAgICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoXCIvaW1hZ2UvZ3JheVN0YXIvZ3JheVN0YXIucG5nXCIpO1xyXG4gICAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICBgO1xyXG5cclxuICBjb25zdCBZZWxsb3dTdGFyID0gc3R5bGVkLmRpdmBcclxuICAgIHdpZHRoOiAyMHB4O1xyXG4gICAgaGVpZ2h0OiAyMHB4O1xyXG4gICAgYmFja2dyb3VuZC1pbWFnZTogdXJsKCkgKFwiL2ltYWdlL3llbGxvd1N0YXIveWVsbG93U3Rhci5wbmdcIik7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgYDtcclxuXHJcbiAgY29uc3QgW2lzU2VsZWN0ZWQsIHNldElzU2VsZWN0ZWRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICBjb25zdCBvbkNsaWNrU3RhciA9IChlKSA9PiB7XHJcbiAgICBzZXRJc1NlbGVjdGVkKGlzU2VsZWN0ZWQpO1xyXG4gICAgZS50YXJnZXQudmFsdWUgPSBpc1NlbGVjdGVkO1xyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8V3JhcHBlcj5cclxuICAgICAge1sxLCAyLCAzLCA0LCA1XS5tYXAoKGVsKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIDxHcmF5U3RhciBvbkNsaWNrPXtvbkNsaWNrU3Rhcn0gLz47XHJcbiAgICAgIH0pfVxyXG4gICAgPC9XcmFwcGVyPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBRdWl6TGV2ZWxVcDtcclxuIl0sIm5hbWVzIjpbInN0eWxlZCIsInVzZVN0YXRlIiwiUXVpekxldmVsVXAiLCJXcmFwcGVyIiwiZGl2IiwiR3JheVN0YXIiLCJZZWxsb3dTdGFyIiwiaXNTZWxlY3RlZCIsInNldElzU2VsZWN0ZWQiLCJvbkNsaWNrU3RhciIsImUiLCJ0YXJnZXQiLCJ2YWx1ZSIsIm1hcCIsImVsIiwib25DbGljayJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/homework/quiz-11-highlevel/index.tsx\n");

/***/ }),

/***/ "@emotion/styled":
/*!**********************************!*\
  !*** external "@emotion/styled" ***!
  \**********************************/
/***/ ((module) => {

module.exports = require("@emotion/styled");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/homework/quiz-11-highlevel/index.tsx"));
module.exports = __webpack_exports__;

})();