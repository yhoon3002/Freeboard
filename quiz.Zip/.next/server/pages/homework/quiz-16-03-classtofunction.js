"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/homework/quiz-16-03-classtofunction";
exports.ids = ["pages/homework/quiz-16-03-classtofunction"];
exports.modules = {

/***/ "./pages/homework/quiz-16-03-classtofunction/index.tsx":
/*!*************************************************************!*\
  !*** ./pages/homework/quiz-16-03-classtofunction/index.tsx ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ MyComponent)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\nfunction MyComponent() {\n    const { 0: count , 1: setCount  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(0);\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();\n    const inputRef = (0,react__WEBPACK_IMPORTED_MODULE_2__.useRef)(null);\n    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{\n        var ref;\n        console.log(\"컴포넌트가 마운트됐습니다~\");\n        (ref = inputRef.current) === null || ref === void 0 ? void 0 : ref.focus();\n    }, []);\n    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{\n        console.log(\"컴포넌트가 변경됐습니다~\");\n    });\n    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{\n        return ()=>{\n            alert(\"컴포넌트가 제거됩니다~\");\n        };\n    }, []);\n    const onClickCounter = ()=>{\n        setCount((prev)=>prev + 1\n        );\n    };\n    const onClickMove = ()=>{\n        router.push(\"/\");\n    };\n    console.log(\"마운트 시작\");\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"input\", {\n                type: \"password\",\n                ref: inputRef\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\scenr\\\\Desktop\\\\codecamp06-lim\\\\quiz\\\\pages\\\\homework\\\\quiz-16-03-classtofunction\\\\index.tsx\",\n                lineNumber: 37,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                children: [\n                    \"카운트: \",\n                    count\n                ]\n            }, void 0, true, {\n                fileName: \"C:\\\\Users\\\\scenr\\\\Desktop\\\\codecamp06-lim\\\\quiz\\\\pages\\\\homework\\\\quiz-16-03-classtofunction\\\\index.tsx\",\n                lineNumber: 38,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                onClick: onClickCounter,\n                children: \"카운트(+1)\"\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\scenr\\\\Desktop\\\\codecamp06-lim\\\\quiz\\\\pages\\\\homework\\\\quiz-16-03-classtofunction\\\\index.tsx\",\n                lineNumber: 39,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                onClick: onClickMove,\n                children: \"이동하기\"\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\scenr\\\\Desktop\\\\codecamp06-lim\\\\quiz\\\\pages\\\\homework\\\\quiz-16-03-classtofunction\\\\index.tsx\",\n                lineNumber: 40,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9ob21ld29yay9xdWl6LTE2LTAzLWNsYXNzdG9mdW5jdGlvbi9pbmRleC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7QUFBdUM7QUFDWTtBQUVwQyxRQUFRLENBQUNJLFdBQVcsR0FBRyxDQUFDO0lBQ3JDLEtBQUssTUFBRUMsS0FBSyxNQUFFQyxRQUFRLE1BQUlILCtDQUFRLENBQUMsQ0FBQztJQUNwQyxLQUFLLENBQUNJLE1BQU0sR0FBR1Asc0RBQVM7SUFFeEIsS0FBSyxDQUFDUSxRQUFRLEdBQUdOLDZDQUFNLENBQW1CLElBQUk7SUFFOUNELGdEQUFTLEtBQU8sQ0FBQztZQUVmTyxHQUFnQjtRQURoQkMsT0FBTyxDQUFDQyxHQUFHLENBQUMsQ0FBd0M7U0FDcERGLEdBQWdCLEdBQWhCQSxRQUFRLENBQUNHLE9BQU8sY0FBaEJILEdBQWdCLEtBQWhCQSxJQUFJLENBQUpBLENBQXVCLEdBQXZCQSxJQUFJLENBQUpBLENBQXVCLEdBQXZCQSxHQUFnQixDQUFFSSxLQUFLO0lBQ3pCLENBQUMsRUFBRSxDQUFDLENBQUM7SUFFTFgsZ0RBQVMsS0FBTyxDQUFDO1FBQ2ZRLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDLENBQWU7SUFDUCxDQUFyQjtJQUVEVCxnREFBUyxLQUFPLENBQUM7UUFDZixNQUFNLEtBQU8sQ0FBQztZQUNaWSxLQUFLLENBQUMsQ0FBYztRQUNGLENBQW5CO0lBQ0gsQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUVMLEtBQUssQ0FBQ0MsY0FBYyxPQUFTLENBQUM7UUFDNUJSLFFBQVEsRUFBRVMsSUFBSSxHQUFLQSxJQUFJLEdBQUcsQ0FBQzs7SUFDN0IsQ0FBQztJQUVELEtBQUssQ0FBQ0MsV0FBVyxPQUFTLENBQUM7UUFDekJULE1BQU0sQ0FBQ1UsSUFBSSxDQUFDLENBQUc7SUFDakIsQ0FBQztJQUVEUixPQUFPLENBQUNDLEdBQUcsQ0FBQyxDQUFRO0lBRVYsTUFBSjs7d0ZBRURRLENBQUs7Z0JBQUNDLElBQUksRUFBQyxDQUFVO2dCQUFDQyxHQUFHLEVBQUVaLFFBQVE7Ozs7Ozt3RkFDbkNhLENBQUc7O29CQUFDLENBQUs7b0JBQU9oQixLQUFLOzs7Ozs7O3dGQUNmaUIsQ0FBQTtnQkFBQ0MsT0FBTyxFQUFFVCxjQUFjOzBCQUFFLENBQU87Ozs7Ozt3RkFDakNRLENBQUE7Z0JBQUNDLE9BQU8sRUFBRVAsV0FBVzswQkFBRSxDQUFJOzs7Ozs7OztBQUd4QyxDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vcXVpei8uL3BhZ2VzL2hvbWV3b3JrL3F1aXotMTYtMDMtY2xhc3N0b2Z1bmN0aW9uL2luZGV4LnRzeD8xNzI0Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gXCJuZXh0L3JvdXRlclwiO1xyXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE15Q29tcG9uZW50KCkge1xyXG4gIGNvbnN0IFtjb3VudCwgc2V0Q291bnRdID0gdXNlU3RhdGUoMCk7XHJcbiAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XHJcblxyXG4gIGNvbnN0IGlucHV0UmVmID0gdXNlUmVmPEhUTUxJbnB1dEVsZW1lbnQ+KG51bGwpO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc29sZS5sb2coXCLsu7Ttj6zrhIztirjqsIAg66eI7Jq07Yq465CQ7Iq164uI64ukflwiKTtcclxuICAgIGlucHV0UmVmLmN1cnJlbnQ/LmZvY3VzKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc29sZS5sb2coXCLsu7Ttj6zrhIztirjqsIAg67OA6rK965CQ7Iq164uI64ukflwiKTtcclxuICB9KTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIHJldHVybiAoKSA9PiB7XHJcbiAgICAgIGFsZXJ0KFwi7Lu07Y+s64SM7Yq46rCAIOygnOqxsOuQqeuLiOuLpH5cIik7XHJcbiAgICB9O1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgY29uc3Qgb25DbGlja0NvdW50ZXIgPSAoKSA9PiB7XHJcbiAgICBzZXRDb3VudCgocHJldikgPT4gcHJldiArIDEpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IG9uQ2xpY2tNb3ZlID0gKCkgPT4ge1xyXG4gICAgcm91dGVyLnB1c2goXCIvXCIpO1xyXG4gIH07XHJcblxyXG4gIGNvbnNvbGUubG9nKFwi66eI7Jq07Yq4IOyLnOyekVwiKTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIDxpbnB1dCB0eXBlPVwicGFzc3dvcmRcIiByZWY9e2lucHV0UmVmfSAvPlxyXG4gICAgICA8ZGl2Puy5tOyatO2KuDoge2NvdW50fTwvZGl2PlxyXG4gICAgICA8YnV0dG9uIG9uQ2xpY2s9e29uQ2xpY2tDb3VudGVyfT7subTsmrTtirgoKzEpPC9idXR0b24+XHJcbiAgICAgIDxidXR0b24gb25DbGljaz17b25DbGlja01vdmV9PuydtOuPme2VmOq4sDwvYnV0dG9uPlxyXG4gICAgPC8+XHJcbiAgKTtcclxufVxyXG4iXSwibmFtZXMiOlsidXNlUm91dGVyIiwidXNlRWZmZWN0IiwidXNlUmVmIiwidXNlU3RhdGUiLCJNeUNvbXBvbmVudCIsImNvdW50Iiwic2V0Q291bnQiLCJyb3V0ZXIiLCJpbnB1dFJlZiIsImNvbnNvbGUiLCJsb2ciLCJjdXJyZW50IiwiZm9jdXMiLCJhbGVydCIsIm9uQ2xpY2tDb3VudGVyIiwicHJldiIsIm9uQ2xpY2tNb3ZlIiwicHVzaCIsImlucHV0IiwidHlwZSIsInJlZiIsImRpdiIsImJ1dHRvbiIsIm9uQ2xpY2siXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/homework/quiz-16-03-classtofunction/index.tsx\n");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/homework/quiz-16-03-classtofunction/index.tsx"));
module.exports = __webpack_exports__;

})();